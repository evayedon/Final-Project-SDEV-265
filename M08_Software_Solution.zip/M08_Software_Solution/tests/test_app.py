
"""
tests.test_app
Purpose: Basic smoke tests and form validation examples for the Flask app.
"""
import pytest
from app import create_app

@pytest.fixture()
def client():
    app = create_app()
    app.config.update(TESTING=True, WTF_CSRF_ENABLED=False)  # disable CSRF for testing
    with app.test_client() as client:
        yield client

def test_home_ok(client):
    resp = client.get('/')
    assert resp.status_code == 200
    assert b"Welcome" in resp.data

def test_register_invalid_email(client):
    resp = client.post('/register', data={
        'first_name': 'Alex',
        'last_name': 'Doe',
        'email': 'not-an-email',
        'password': 'abc12345'
    }, follow_redirects=True)
    assert b"Invalid email address." in resp.data

def test_contact_over_length_subject(client):
    resp = client.post('/contact', data={
        'name': 'Taylor',
        'email': 'taylor@example.com',
        'subject': 'S'*61,
        'message': 'Hello'
    }, follow_redirects=True)
    assert b"Field must be between 0 and 60 characters long." in resp.data

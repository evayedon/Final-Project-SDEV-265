
"""
app.main.routes
Purpose: Define page routes for the main blueprint, providing Intro + 4 category pages,
         plus a Contact form to demonstrate validation and secure coding.
"""
from flask import Blueprint, render_template, flash, redirect, url_for, current_app
from ..forms import ContactForm
import json, os

main_bp = Blueprint('main', __name__)

def load_images():
    "Load image metadata from app/content/images.json"
    content_path = os.path.join(current_app.root_path, 'content', 'images.json')
    try:
        with open(content_path, 'r', encoding='utf-8') as fh:
            return json.load(fh)
    except Exception:
        return {}

@main_bp.route('/')
def intro():
    """Purpose: Intro page with hero and overview cards (use header nav to explore)."""
    return render_template('intro.html', title='Intro')

@main_bp.route('/video-games')
def video_games():
    """Purpose: Page introducing Video Games with examples, descriptions, and images."""
    images = load_images().get('video_games', [])
    examples = [
        {"title": "The Legend of Zelda: Breath of the Wild", "desc": "Open-world action-adventure with exploration and physics-driven puzzles."},
        {"title": "Minecraft", "desc": "Sandbox building and survival game with infinite blocky worlds."},
        {"title": "Fortnite", "desc": "Battle royale shooter with building mechanics and seasonal events."},
    ]
    return render_template('video_games.html', title='Video Games', examples=examples, images=images)

@main_bp.route('/board-games')
def board_games():
    """Purpose: Page introducing Board Games with examples, descriptions, and images."""
    images = load_images().get('board_games', [])
    examples = [
        {"title": "Catan", "desc": "Trade, build, and settle to earn victory points on a modular island."},
        {"title": "Ticket to Ride", "desc": "Collect train cards to claim routes across a map."},
        {"title": "Pandemic", "desc": "Cooperative game to stop global disease outbreaks."},
    ]
    return render_template('board_games.html', title='Board Games', examples=examples, images=images)

@main_bp.route('/card-games')
def card_games():
    """Purpose: Page introducing Card Games with examples, descriptions, and images."""
    images = load_images().get('card_games', [])
    examples = [
        {"title": "Poker", "desc": "Classic betting game with hand rankings and bluffing."},
        {"title": "Uno", "desc": "Family shedding game with color/number matching and action cards."},
        {"title": "Magic: The Gathering", "desc": "Collectible card game with deck-building and strategic combos."},
    ]
    return render_template('card_games.html', title='Card Games', examples=examples, images=images)

@main_bp.route('/tabletop-games')
def tabletop_games():
    """Purpose: Page introducing Tabletop Roleplaying/Minis games with examples, descriptions, and images."""
    images = load_images().get('tabletop_games', [])
    examples = [
        {"title": "Dungeons & Dragons", "desc": "Story-driven roleplaying with dice-based conflict resolution."},
        {"title": "Warhammer 40,000", "desc": "Miniatures wargame with army building and tactical battles."},
        {"title": "Pathfinder", "desc": "d20 roleplaying system focused on character customization."},
    ]
    return render_template('tabletop_games.html', title='Tabletop Games', examples=examples, images=images)

@main_bp.route('/contact', methods=['GET', 'POST'])
def contact():
    """Purpose: Contact form demonstrating input validation and fixed-length constraints."""
    form = ContactForm()
    if form.validate_on_submit():
        flash("Message received! We'll get back to you soon.", 'success')
        return redirect(url_for('main.intro'))
    return render_template('contact.html', title='Contact', form=form)

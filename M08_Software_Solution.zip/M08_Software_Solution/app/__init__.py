
"""
app.__init__
Purpose: Application factory for the Flask app. Sets up configuration, blueprints, and CSRF protection.
"""
from flask import Flask
from flask_wtf import CSRFProtect

csrf = CSRFProtect()

def create_app():
    """
    Purpose: Create and configure the Flask application instance.
    Returns:
        Flask: Configured Flask app
    """
    app = Flask(__name__)
    # SECURITY: Use a strong secret key in production and keep it secret!
    app.config['SECRET_KEY'] = 'change-this-in-production-please'  # secret used for CSRF & session

    # Register blueprints
    from .main.routes import main_bp
    app.register_blueprint(main_bp)

    # Enable CSRF protection
    csrf.init_app(app)

    return app


"""
run
Purpose: App entry point to run the Flask development server.
"""
from app import create_app

app = create_app()

if __name__ == '__main__':
    # SECURITY: For local dev/testing only. In production, use a proper WSGI server.
    app.run(debug=True)
